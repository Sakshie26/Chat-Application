const { MongoClient, ObjectId } = require('mongodb');
const readline = require('readline');
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const uri = 'mongodb://localhost:27017'; // or your MongoDB Atlas URI
const client = new MongoClient(uri);

const main = async () => {
  await client.connect();
  const db = client.db('chatapp');
  const messages = db.collection('messages');

  const menu = () => {
    console.log(`\n--- Terminal Chat CRUD Menu ---
1. Create Message
2. Read Messages
3. Update Message
4. Delete Message
5. Exit`);
    rl.question('Choose an option: ', async (option) => {
      switch (option.trim()) {
        case '1':
          rl.question('Enter username: ', (username) => {
            rl.question('Enter message: ', async (message) => {
              await messages.insertOne({
                username,
                message,
                timestamp: new Date()
              });
              console.log('Message saved.');
              menu();
            });
          });
          break;

        case '2':
          const allMessages = await messages.find().sort({ timestamp: 1 }).toArray();
          allMessages.forEach((msg) =>
            console.log(`${msg._id} | ${msg.username}: ${msg.message}`)
          );
          menu();
          break;

        case '3':
          rl.question('Enter Message ID to update: ', (id) => {
            rl.question('Enter new message: ', async (newMessage) => {
              const result = await messages.updateOne(
                { _id: new ObjectId(id) },
                { $set: { message: newMessage, timestamp: new Date() } }
              );
              if (result.modifiedCount) {
                console.log('Message updated.');
              } else {
                console.log('No message found.');
              }
              menu();
            });
          });
          break;

        case '4':
          rl.question('Enter Message ID to delete: ', async (id) => {
            const result = await messages.deleteOne({ _id: new ObjectId(id) });
            if (result.deletedCount) {
              console.log('Message deleted.');
            } else {
              console.log('No message found.');
            }
            menu();
          });
          break;

        case '5':
          console.log('Exiting...');
          rl.close();
          await client.close();
          break;

        default:
          console.log('Invalid choice.');
          menu();
          break;
      }
    });
  };

  menu();
};

main().catch(console.error);
