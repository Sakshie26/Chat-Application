from pymongo import MongoClient
from datetime import datetime, timezone
from bson.objectid import ObjectId

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017")
db = client["chatapp"]
messages = db["messages"]

def create_message():
    username = input("Enter username: ")
    msg = input("Enter your message: ")
    message = {
        "username": username,
        "message": msg,
        "timestamp": datetime.now(timezone.utc)
    }
    result = messages.insert_one(message)
    print(f"Message inserted with ID: {result.inserted_id}")

def read_messages():
    print("\nAll Messages:")
    for msg in messages.find().sort("timestamp"):
        print(f"{msg['_id']} | {msg['username']}: {msg['message']}")

def update_message():
    _id = input("Enter message ID to update: ")
    new_msg = input("Enter new message: ")
    result = messages.update_one(
        {"_id": ObjectId(_id)},
        {"$set": {"message": new_msg, "timestamp": datetime.now(timezone.utc)}}
    )
    if result.modified_count:
        print("Message updated successfully.")
    else:
        print("No message found with that ID.")

def delete_message():
    _id = input("Enter message ID to delete: ")
    result = messages.delete_one({"_id": ObjectId(_id)})
    if result.deleted_count:
        print("Message deleted successfully.")
    else:
        print("No message found with that ID.")

# Main loop
while True:
    print("\n--- Terminal Chat CRUD Menu ---")
    print("1. Create Message")
    print("2. Read Messages")
    print("3. Update Message")
    print("4. Delete Message")
    print("5. Exit")
    choice = input("Enter choice: ")

    if choice == "1":
        create_message()
    elif choice == "2":
        read_messages()
    elif choice == "3":
        update_message()
    elif choice == "4":
        delete_message()
    elif choice == "5":
        break
    else:
        print("Invalid option. Please choose again.")
