from pymongo import MongoClient
from datetime import datetime, timezone
import threading
import time

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017")
db = client["chatapp"]
messages = db["messages"]

# Ask for username
username = input("Enter your username: ")

# Function to send messages
def send_message():
    while True:
        msg = input()
        if msg.lower() == 'exit':
            break
        message = {
            "username": username,
            "message": msg,
            "timestamp": datetime.now(timezone.utc)
        }
        messages.insert_one(message)

# Function to receive messages from other users
def receive_messages():
    last_time = datetime.now(timezone.utc)
    while True:
        new_messages = messages.find({"timestamp": {"$gt": last_time}}).sort("timestamp")
        for msg in new_messages:
            if msg["username"] != username:
                print(f'\n{msg["username"]}: {msg["message"]}')
                last_time = msg["timestamp"]
        time.sleep(1)

# Start receiving thread
receiver = threading.Thread(target=receive_messages)
receiver.daemon = True
receiver.start()

# Start sending loop
send_message()
print("You have left the chat.")

